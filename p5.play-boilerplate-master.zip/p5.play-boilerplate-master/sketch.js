var player1,player1Image;
var player2,player2Image;


function preload(){
player1Image=loadImage("papa.png");
player2Image=loadImage("mama.png");
backgroundImage=loadImage("back.png")
}



function setup() {
  createCanvas(1200,800);
   player1=createSprite(200,520,60,40);
   player2=createSprite(1000,520,10,1200);
   player1.addImage("player1",player1Image);
   player2.addImage("player2",player2Image);
}



function draw(){
  background.addImage("background",backgroundImage,);
  background(255);  
  drawSprites();
}